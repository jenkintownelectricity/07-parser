"""
WSGI entry point for production deployment.
Use with gunicorn, waitress, or other WSGI servers.
"""
from app import app

if __name__ == "__main__":
    app.run()
